<?php 
require_once('function.php');
require_once('functions_print.php');
require_once('var.php');
$paso=4;
if ($paso == 4) {

    $pintar_formulario = draw_form($formulario, $paso);

}


require_once('template.php');
?>

