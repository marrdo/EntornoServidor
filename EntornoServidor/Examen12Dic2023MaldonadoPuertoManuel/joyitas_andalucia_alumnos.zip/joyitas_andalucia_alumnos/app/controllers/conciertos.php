<?php
class ConciertosController{
    public function listar($params){
        echo 'se ha ejecutado el método listar del controlador de conciertos';
    }
}