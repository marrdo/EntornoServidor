<td class="px-6 py-4 whitespace-nowrap text-sm text-center text-gray-100">
    <?php echo e($slot); ?>

</td><?php /**PATH /var/www/html/EntornoServidor/EntornoServidor/Tema10/PracticaCRUD/CRUDMonumentos/resources/views/components/table-cell.blade.php ENDPATH**/ ?>