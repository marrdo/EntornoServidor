<td class="px-6 py-4 whitespace-nowrap text-sm text-center text-gray-100">
    {{ $slot }}
</td>