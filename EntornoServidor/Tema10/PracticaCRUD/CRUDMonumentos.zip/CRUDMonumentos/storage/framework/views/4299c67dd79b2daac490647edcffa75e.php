<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Comprobamos si hay un mensaje de éxito en la sesión y lo mostramos -->
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <!-- Comprobamos si hay monumentos y si su cantidad es mayor que cero -->
    <?php if(!empty($monumentos)): ?>
    <?php
    // Obtener el primer monumento de la colección
    $firstMonumento = $monumentos->first();

    // Obtener las claves (nombres de las columnas) del primer monumento y convertirlas en un array
    $headers = array_keys($firstMonumento->toArray());
    // Esto obtiene las claves (nombres de las columnas) del primer monumento de la colección y las convierte en un array.

    // Eliminar del array de nombres de columnas las claves que no queremos mostrar en la tabla (id, created_at, updated_at)
    $headers = array_diff($headers, ['id', 'created_at', 'updated_at']);
    // Esto elimina del array de nombres de columnas las claves que no queremos mostrar en la tabla (como 'id', 'created_at' y 'updated_at')

    // Definimos una función para obtener el nombre de la provincia a partir de su ID
    function obtenerNombreProvincia($idProvincia, $provincias) {
    foreach ($provincias as $provincia) {
    // Iteramos sobre el array de provincias y comparamos los IDs
    if ($provincia['id'] === $idProvincia) {
    return $provincia['nombre']; // Si encontramos la provincia, devolvemos su nombre
    }
    }
    return 'Jamaica'; // Si no encontramos la provincia, devolvemos una cadena
    }

    // Mapeamos los monumentos y cambiamos el valor de 'provincia' por el nombre de la provincia
    $monumentos = $monumentos->map(function ($monumento) use ($provincias) {
    // Utilizamos la función definida anteriormente para obtener el nombre de la provincia
    $monumento['provincia'] = obtenerNombreProvincia($monumento['provincia'], $provincias);
    // Devolvemos solo las tres primeras columnas de cada monumento
    return array_slice($monumento->toArray(), 1, 3);
    })->all();
    ?>

    <!-- Mostramos una tabla con los monumentos -->
    <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => ['headers' => $headers,'rows' => $monumentos]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($headers),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($monumentos)]); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>

    <section>
        <h2>Listado de Json</h2>
        <ul id="lista-monumentos"></ul>
    </section>
    

    
    <script>
        // Datos JSON de monumentos
        var monumentosData = <?php echo $monumentos_json; ?>;

        // Función para mostrar monumentos en el DOM
        function mostrarMonumentos() {
            var listaMonumentos = document.getElementById('lista-monumentos');

            // Limpiamos la lista antes de agregar nuevos elementos
            listaMonumentos.innerHTML = '';

            // Iteramos sobre los datos JSON y creamos elementos de lista para cada monumento
            monumentosData.forEach(monumento => {
                var listItem = document.createElement('li');
                listItem.textContent = `-/ ${monumento.nombre} - Aforo: ${monumento.aforo}`;
                listaMonumentos.appendChild(listItem);
            });
        }

        // Mostrar los monumentos cuando se carga la página
        document.addEventListener('DOMContentLoaded', function() {
            mostrarMonumentos();
        });
    </script>

    <?php else: ?>
    <!-- Mostramos un mensaje si no hay monumentos para mostrar -->
    <section class="bg-red-500 text-white p-4">
        <p>No hay monumentos para mostrar.</p>
    </section>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/EntornoServidor/EntornoServidor/Tema10/PracticaCRUD/CRUDMonumentos/resources/views/monumento/index.blade.php ENDPATH**/ ?>