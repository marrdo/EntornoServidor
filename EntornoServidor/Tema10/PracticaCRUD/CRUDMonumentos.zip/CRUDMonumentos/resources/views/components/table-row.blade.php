<tr class="bg-white divide-y divide-gray-200">
    {{ $slot }}
</tr>