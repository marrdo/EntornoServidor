<tr class="bg-white divide-y divide-gray-200">
    <?php echo e($slot); ?>

</tr><?php /**PATH /var/www/html/EntornoServidor/EntornoServidor/Tema10/PracticaCRUD/CRUDMonumentos/resources/views/components/table-row.blade.php ENDPATH**/ ?>