<?php

//TODO: Zona de declaración de constantes, etc

//TODO: Otras cosita que ya veremos

require_once('../app/core.php');

$core = new Core();
