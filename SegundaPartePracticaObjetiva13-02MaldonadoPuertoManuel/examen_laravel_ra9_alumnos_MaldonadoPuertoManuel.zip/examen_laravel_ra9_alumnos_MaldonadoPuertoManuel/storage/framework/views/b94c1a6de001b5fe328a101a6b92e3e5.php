<svg fill="currentColor" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
  <g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
  <g id="SVGRepo_iconCarrier"> 
    <path d="M0 5.04V4l4-4h8l4 4v1.04L8 16 0 5.04zM2 5l6 8.5L4 5H2zm12 0h-2l-4 8.5L14 5zM6 5l2 6 2-6H6zM4 2L2 4h2l2-2H4zm8 0h-2l2 2h2l-2-2zM7 2L6 4h4L9 2H7z" fill-rule="evenodd"></path> </g></svg>
<?php /**PATH /var/www/html/EntornoServidor/SegundaPartePracticaObjetiva13-02MaldonadoPuertoManuel/examen_laravel_ra9_alumnos/resources/views/components/application-logo.blade.php ENDPATH**/ ?>