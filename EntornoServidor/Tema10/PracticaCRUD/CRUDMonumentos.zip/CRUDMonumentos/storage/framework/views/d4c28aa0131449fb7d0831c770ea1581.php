<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['options' => [], 'id' => null, 'name' => null, 'disabled' => false, 'required' => false, 'nomObj' => 'nombre']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['options' => [], 'id' => null, 'name' => null, 'disabled' => false, 'required' => false, 'nomObj' => 'nombre']); ?>
<?php foreach (array_filter((['options' => [], 'id' => null, 'name' => null, 'disabled' => false, 'required' => false, 'nomObj' => 'nombre']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<select id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" <?php echo e($disabled ? 'disabled' : ''); ?> <?php echo e($required ? 'required' : ''); ?> <?php echo $attributes->merge(['class' => 'border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm']); ?>>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($registro->id); ?>"><?php echo e($registro->$nomObj); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>



<?php /**PATH /var/www/html/EntornoServidor/EntornoServidor/Tema10/PracticaCRUD/CRUDMonumentos/resources/views/components/select-input.blade.php ENDPATH**/ ?>