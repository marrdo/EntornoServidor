<tr wire:poll.5s class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
    <td class="px-6 py-4 font-bold text-gray-900 whitespace-nowrap dark:text-white ">
        
        <input wire:key="nombre_<?php echo e($monumento->id); ?>" class="text-gray-900" type="text" wire:model.live.debounce.1000ms="nombre">
    </td>
    <td class="px-6 py-4 font-bold text-gray-900 whitespace-nowrap dark:text-white ">
        
        <label for="provincia" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Selecciona la provincia</label>
        <select wire:model.live="provincia" wire:key="provincia_<?php echo e($monumento->id); ?>" id="provincia" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            <option value="<?php echo e($monumento->provincias->id); ?>" selected><?php echo e($monumento->provincias->abreviatura); ?> -- <?php echo e($monumento->provincias->nombre); ?></option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->abreviatura); ?> -- <?php echo e($provincia->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </select>
    </td>
    <td class="px-6 py-4 font-bold text-gray-900 whitespace-nowrap dark:text-white ">
        
        <input type="text" class="text-gray-900" wire:key="aforo_<?php echo e($monumento->aforo); ?>" wire:model.live="aforo">
    </td>
    <td class="px-6 py-4 font-bold text-gray-900 whitespace-nowrap dark:text-white ">
        
        
        <label for="user" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Selecciona al empleado</label>
        <select wire:model.live="user" id="user" name="user" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            <option value="<?php echo e($monumento->user->id); ?>" selected>Id:<?php echo e($monumento->user->id); ?>--<?php echo e($monumento->user->name); ?> -><?php echo e($monumento->phone ? $monumento->phone->numero : 'NoPhone'); ?></option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> -> <?php echo e($user->phone->numero); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </select>
    </td>
    <td class="px-6 py-4 font-bold text-gray-900 whitespace-nowrap dark:text-white ">
        
        <button wire:click="update" type="button" class="text-white my-2 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-gray-600 dark:hover:bg-blue-800 dark:focus:ring-gray-100">Actualizar</button>
        <button wire:click="destroy(<?php echo e($monumento->id); ?>)" type="button" class="text-white my-2 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-gray-600 dark:hover:bg-blue-800 dark:focus:ring-gray-100">Eliminar</button>
        <button wire:click="showModal(<?php echo e($monumento->id); ?>)" wire:key="modal_<?php echo e($monumento->id); ?>" type="button" class="text-white my-2 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-gray-600 dark:hover:bg-blue-800 dark:focus:ring-gray-100">Desplegar monumento</button>
        <!--[if BLOCK]><![endif]--><?php if(session('succes') && session('id')===$monumento->id): ?>
        <p class="mt-1 text-sm text-green-600"><strong><?php echo e(session('succes')); ?></strong></p>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </td>
</tr>
<?php /**PATH /var/www/html/EntornoServidor/SegundaPartePracticaObjetiva13-02MaldonadoPuertoManuel/examen_laravel_ra9_alumnos/resources/views/livewire/fila.blade.php ENDPATH**/ ?>