<?php
require_once('../app/iniciador.php');
?>