<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Metadatos -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <!-- Enlace al CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <!-- Script de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    
    <!-- Título de la página -->
    <title>Formulario de Monumento</title>
</head>
<body>
    <main class="container">
        <!-- Contenedor principal -->
        <div class="row mx-auto ">
            <!-- Enlace para volver al índice -->
            <a class="col-12 mx-auto p-3 d-block " href="<?php echo e(route('monumento.index')); ?>" class="">Index</a>
            
            <!-- Formulario de creación de monumento -->
            <form class="col-12 mx-auto p-3 gap-2" method="POST" action="<?php echo e(route('monumento.store')); ?>">
                <?php echo csrf_field(); ?> <!-- Directiva de Blade para protección CSRF -->
                
                <!-- Campo de nombre del monumento -->
                <article class="p-2">
                    <label for="nombre" class="">Nombre: </label>
                    <input type="text" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class=" bg-red-800 text-dark"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </article>
                
                <!-- Campo de aforo del monumento -->
                <article class="p-2">
                    <label for="aforo" class="">Aforo:</label>
                    <input type="number" name="aforo" id="aforo">
                    <?php $__errorArgs = ['aforo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class=" bg-red-800 text-dark"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </article>
                
                <!-- Selección de provincia del monumento -->
                <article class="p-2">
                    <label for="provincia" class=""> Provincia</label>
                    <select name="provincia" id="provincia">
                        <option value="">Escoja una provincia</option>
                        <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class=" bg-red-800 text-dark"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </article>
                
                <!-- Botón de envío del formulario -->
                <input type="submit" value="Enviar" class="p-2">
            </form>
        </div>
    </main>
</body>
</html>
<?php /**PATH /var/www/html/EntornoServidor/EntornoServidor/Tema10/PracticaCRUD/CRUDMonumentos/resources/views/monumento/create.blade.php ENDPATH**/ ?>